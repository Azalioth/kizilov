﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kuchkina_kursovaya.DataBase
{
    class Rabotnick1
    {
        public int id;
        public string FullName;
        public string login;
        public string password;
        public role RabotnickRole;
        public enum role
        {
            client,
            admin,
            Rabotnick
        }

        static public string getRoleName(role role)
        {
            switch (role)
            {
                case role.client:
                    return "client";
                case role.admin:
                    return "admin";
                case role.Rabotnick:
                    return "Rabotnick";
                default:
                    return "Client";

            }
        }

        static public role getRoleByName(string roleName)
        {
            switch (roleName)
            {
                case "client":
                    return role.client;
                case "Rabotnick":
                    return role.Rabotnick;
                case "admin":
                    return role.admin;
                default:
                    return role.client;
            }
        }
    }
}
