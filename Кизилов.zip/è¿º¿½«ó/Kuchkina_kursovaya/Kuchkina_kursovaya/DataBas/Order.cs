﻿using Kuchkina_kursovaya.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kuchkina_kursovaya.DataBas
{
    public class Order
    {
        public int id;
        public List<TovarInCart> tovars;
    }
}
