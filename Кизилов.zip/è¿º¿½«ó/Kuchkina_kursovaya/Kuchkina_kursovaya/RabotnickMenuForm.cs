﻿using Kuchkina_kursovaya;
using Kuchkina_kursovaya.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kuchkina_kursovaya
{
    public partial class RabotnickMenuForm : TemplateForm
    {
        public RabotnickMenuForm()
        {
            InitializeComponent();
            ProgramState pState = new ProgramState();
            Rabotnick1 authorizedUser = pState.GetAuthorizedUser();
            if (authorizedUser.RabotnickRole == Rabotnick1.role.Rabotnick)
            {
                AddTovar_b.Visible = false;
                GridView_b.Visible = false;
                AddRabotnick_b.Visible = false;
                
            }

        }

        private void RabotnickMenuForm_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RabotnickAddForm form = new RabotnickAddForm();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UsersGridViewForm form = new UsersGridViewForm();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TovarGridVeiwForm form = new TovarGridVeiwForm();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TovarAddForm form = new TovarAddForm();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OrderForm form = new OrderForm();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OrdersGridViewForm form = new OrdersGridViewForm();
            this.Hide();
            form.Show();
            form.Owner = this;
        }
    }
}
