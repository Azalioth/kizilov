﻿using Kuchkina_kursovaya.DataBas;
using Kuchkina_kursovaya;
using Kuchkina_kursovaya.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kuchkina_kursovaya
{
    public partial class CheckForm : TemplateForm
    {
        public CheckForm(Order order)
        {
            InitializeComponent();
            ProgramState pState = new ProgramState();
            Rabotnick1 user = pState.GetAuthorizedUser();
            string html = @"<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
</head>
<body>
<style>
.title, .address, .list-title, .post-script{
margin-left: 18px;
}
div{
margin-bottom: 12px;
}
table{
border-collapse: collapse;
}
td{
border: black solid 1px;
padding: 8px;
}
</style>
<div class='title'>Склад хозтоваров</div>
<div class='address'>Г. Курск, ул. улица</div>
<div class='list-title'>Список товаров</div>
<table>
<tbody>
<tr>
<td>Наименование</td>
<td>Количество</td>
<td>Стоимость</td>
</tr>
";
            for (int i = 0; i < order.tovars.Count; i++)
            {
                html += $"<tr><td>{order.tovars[i].tovar.title}</td><td>{order.tovars[i].count}</td><td>{order.tovars[i].count * order.tovars[i].tovar.price}</td></tr>";

            }
            double totalSum = 0;

            for (int i = 0; i < order.tovars.Count; i++)
            {
                totalSum += order.tovars[i].tovar.price * order.tovars[i].count;
            }
            html += $@"
</tbody>
</table>
<div class='br'></div>
<div class='total'>Итог: {totalSum} руб.</div>
<div class='post-script'>Спасибо за покупку!</div>
</body>
</html>";
            webBrowser1.DocumentText = html;

        }

        private void CheckForm_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.ShowPrintDialog();
        }
        void PrintPageHandler(object sender, PrintPageEventArgs e)
        {
            
        }
    }
}
