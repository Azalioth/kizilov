﻿using Kuchkina_kursovaya;
using Kuchkina_kursovaya.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kuchkina_kursovaya
{
    public partial class UsersGridViewForm : TemplateForm
    {

        bool isRowEdit = false;
        int rowEditNumber = -1;
        public UsersGridViewForm()
        {
            InitializeComponent();
        }

        private void UsersGridViewForm_Load(object sender, EventArgs e)
        {
            loadAndDisplayUsersFromDB();
        }
        private void loadAndDisplayUsersFromDB(string searchText = null)
        {
            DataBaseControl dbController = new DataBaseControl();
            List<Rabotnick1> users = dbController.getUsers();

            displayUsers(users, searchText);
        }
        private void displayUsers(List<Rabotnick1> users, string searchText = null)
        {
            RabotnicksGridView.Rows.Clear();
            for (int i = 0; i < users.Count; i++)
            {
                if (searchText != null)
                {
                    if (!users[i].FullName.Contains(searchText))
                    {
                        continue;
                    }
                }
                RabotnicksGridView.Rows.Add(users[i].id, users[i].FullName, users[i].login, users[i].password,  Rabotnick1.getRoleName(users[i].RabotnickRole), "Edit", "Delete");
            }
        }

        private void UsersGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(e.RowIndex < 0)
            {
                return;
            }
            if (e.ColumnIndex == 5)
            {
                if (!isRowEdit)
                {
                    startRowEdit(e.RowIndex);
                }
                else
                {
                    if (rowEditNumber == e.RowIndex)
                    {
                        saveRow();
                    }
                    else
                    {
                        saveRow();
                        startRowEdit(e.RowIndex);
                    }
                }
            }
            if (e.ColumnIndex == 6)
            {
                if(MessageBox.Show("Удалить это поле?","Подтверждение",MessageBoxButtons.YesNo)==DialogResult.Yes)
                deleteRow(e.RowIndex);
            }
        }

        private void startRowEdit(int row)
        {
            isRowEdit = true;
            rowEditNumber = row;
            RabotnicksGridView.Rows[row].Cells[1].ReadOnly = false;
            RabotnicksGridView.Rows[row].Cells[2].ReadOnly = false;
            RabotnicksGridView.Rows[row].Cells[3].ReadOnly = false;
            RabotnicksGridView.Rows[row].Cells[4].ReadOnly = false;


            RabotnicksGridView.Rows[row].Cells[5].Value = "Save";
        }

        private void saveRow()
        {
            Rabotnick1 user = new Rabotnick1();
            user.login = RabotnicksGridView.Rows[rowEditNumber].Cells[1].Value.ToString();
            user.password = RabotnicksGridView.Rows[rowEditNumber].Cells[2].Value.ToString();
            user.FullName = RabotnicksGridView.Rows[rowEditNumber].Cells[3].Value.ToString();
            user.RabotnickRole = Rabotnick1.getRoleByName(RabotnicksGridView.Rows[rowEditNumber].Cells[3].Value.ToString());


            RabotnicksGridView.Rows[rowEditNumber].Cells[1].ReadOnly = true;
            RabotnicksGridView.Rows[rowEditNumber].Cells[2].ReadOnly = true;
            RabotnicksGridView.Rows[rowEditNumber].Cells[3].ReadOnly = true;
            RabotnicksGridView.Rows[rowEditNumber].Cells[4].ReadOnly = true;


            RabotnicksGridView.Rows[rowEditNumber].Cells[5].Value = "Edit";

            DataBaseControl dbController = new DataBaseControl();

            dbController.UpdateUser(rowEditNumber, user);

            isRowEdit = false;
            rowEditNumber = -1;
        }

        private void deleteRow(int rowId)
        {
            DataBaseControl dbController = new DataBaseControl();

            dbController.DeleteUser(rowId);

            loadAndDisplayUsersFromDB();
        }

        private void SearchInput_TextChanged(object sender, EventArgs e)
        {
            loadAndDisplayUsersFromDB(SearchInput.Text);
        }

        private void RabotnicksGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

