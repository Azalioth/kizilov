﻿using Kuchkina_kursovaya;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kuchkina_kursovaya
{
    public partial class RabotnickAuthorizationForm : TemplateForm
    {
        public RabotnickAuthorizationForm()
        {
            InitializeComponent();
        }

        private void RabotnickAuthorizationForm_Load(object sender, EventArgs e)
        {

        }

        private void Submit_b_Click(object sender, EventArgs e)
        {
            DataBaseControl dbController = new DataBaseControl();

            string login = LoginInput.Text.Trim();
            string password = PasswordInput.Text.Trim();
            if (login != "" && password != "")
            {
                try
                {
                    dbController.AuthorizateUser(login, password);
                    RabotnickMenuForm form = new RabotnickMenuForm();
                    form.Owner = this.Owner;
                    form.Show();
                    this.Owner = null;
                    this.Close();
                }
                catch
                {
                    MessageBox.Show("Неверный логин или пароль");
                    PasswordInput.Text = "";
                }
            }
        }

        private void LoginInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
