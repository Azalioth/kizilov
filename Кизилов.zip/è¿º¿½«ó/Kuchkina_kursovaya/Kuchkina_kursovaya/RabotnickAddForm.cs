﻿using Kuchkina_kursovaya;
using Kuchkina_kursovaya.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kuchkina_kursovaya
{
    public partial class RabotnickAddForm : TemplateForm
    {
        public RabotnickAddForm()
        {
            InitializeComponent();
        }

        private void RabotnickAddForm_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Submit_b_Click(object sender, EventArgs e)
        {
            string fullName = FullNameInput.Text.Trim();
            string login = LoginInput.Text.Trim();
            string password = PasswordInput.Text.Trim();
            string userRole = "";
            if (RabotnickRoleComboBox.SelectedItem != null)
            {
                userRole = RabotnickRoleComboBox.SelectedItem.ToString().Trim();
            }

            if (fullName != "" && login != "" && password != "" && userRole != "")
            {
                Rabotnick1 newUser = new Rabotnick1();
                newUser.FullName = fullName;
                newUser.login = login;
                newUser.password = password;
                newUser.RabotnickRole = Rabotnick1.getRoleByName(userRole);


                DataBaseControl dbController = new DataBaseControl();
                dbController.AddUser(newUser);

                this.Close();
            }
            else 
            {
                MessageBox.Show("Вы не заполнили все поля");
            }
        }
    }
}
